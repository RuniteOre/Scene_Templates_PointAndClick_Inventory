AI 1 - The cat, he will always follow you around

AI 2 - The Blue Farmer, he will walk wood back and forth and be interrupted if you bump into him

AI 3 - The Green guy, he will walk randomly, and chase you if you're too close and spin if he collides

It's a point and click for movement, Middle mouse and move mouse for camera rotation, and mouse wheel to zoom in and out